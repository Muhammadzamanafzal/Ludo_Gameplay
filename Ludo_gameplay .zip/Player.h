#pragma once
#include <vector>
#include <string>
#include "Token.h"
using namespace std;

class Player {
private:
    int           id;
    string        name;
    PlayerColor   color;
    vector<Token> tokens;
    int           finishedTokens;

public:
    Player(int id, const string& name, PlayerColor color);

    int                   getId()           const;
    const string&         getName()         const;
    PlayerColor           getColor()        const;
    int                   getFinishedCount()const;
    int                   getBaseCount()    const;

    Token&                getToken(int idx);
    const Token&          getToken(int idx) const;
    vector<Token>&        getTokens();
    const vector<Token>&  getTokens()       const;

    vector<Token*> getMovableTokens(int diceValue);

    bool hasWon()                const;
    void incrementFinished();
    void setFinishedTokens(int n);
};
