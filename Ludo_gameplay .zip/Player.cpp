#include "Player.h"
using namespace std;

Player::Player(int id, const string& name, PlayerColor color)
    : id(id), name(name), color(color), finishedTokens(0)
{
    for (int i = 0; i < 4; ++i)
        tokens.emplace_back(i, color);
}

int           Player::getId()            const { return id; }
const string& Player::getName()          const { return name; }
PlayerColor   Player::getColor()         const { return color; }
int           Player::getFinishedCount() const { return finishedTokens; }

int Player::getBaseCount() const {
    int count = 0;
    for (const Token& t : tokens)
        if (t.isAtHome()) ++count;
    return count;
}

Token&       Player::getToken(int idx)       { return tokens[idx]; }
const Token& Player::getToken(int idx) const { return tokens[idx]; }

vector<Token>&       Player::getTokens()       { return tokens; }
const vector<Token>& Player::getTokens() const { return tokens; }


vector<Token*> Player::getMovableTokens(int diceValue) {
    vector<Token*> movable;
    for (Token& t : tokens) {
        if (t.isFinished()) continue;

        if (t.isAtHome()) {
            if (diceValue == 6) movable.push_back(&t);
        }
        else {
            movable.push_back(&t);
        }
    }
    return movable;
}

bool Player::hasWon() const {
    return finishedTokens >= 4;
}

void Player::incrementFinished() { ++finishedTokens; }

void Player::setFinishedTokens(int n) { finishedTokens = n; }
