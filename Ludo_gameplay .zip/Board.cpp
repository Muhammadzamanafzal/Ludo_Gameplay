#include "Board.h"
#include <stdexcept>
using namespace std;

const set<int> SAFE_SET = { 0, 8, 13, 21, 26, 34, 39, 47 };

Board::Board() : safeCells(SAFE_SET) {
    for (int i = 0; i < 52; ++i)
        cells.emplace_back(i, SAFE_SET.count(i) > 0);
}
 int Board::startOffset(PlayerColor c) const {
    switch (c) {
    case PlayerColor::CRED:    return 13;
    case PlayerColor::CGREEN:  return 26;
    case PlayerColor::CYELLOW: return 39;
    case PlayerColor::CBLUE:   return 0;
    }
    return 0;
}

bool Board::isSafe(int trackIndex) const {
    return safeCells.count(trackIndex) > 0;
}

Position Board::getNextPosition(const Position& pos, int steps, PlayerColor color) const {
    int start = startOffset(color);

    if (pos.isBase()) {
        return Position(start);
    }

    if (pos.isFinished()) return pos;

    if (pos.isHomeCol()) {
        int homeStep = pos.trackIndex - 100;   
        int next     = homeStep + steps;
        if (next == 6) return Position(999);   
        if (next >  6) return pos;             
        return Position(100 + next);
    }

    int relative    = (pos.trackIndex - start + 52) % 52;
    int newRelative = relative + steps;

    if (newRelative < 51) {
        return Position((start + newRelative) % 52);
    }
    else if (newRelative == 51) {
        return Position(100);
    }
    else {
        int homeStep = newRelative - 51;   
        if (homeStep == 6) return Position(999);   
        if (homeStep >  6) return pos;             
        return Position(100 + homeStep - 1);       
    }
}

bool Board::isValidMove(const Token& token, int steps) const {
    if (token.isFinished()) return false;

    if (token.isAtHome()) {
        return steps == 6;
    }

    Position next = getNextPosition(token.getPosition(), steps, token.getColor());

    if (next == token.getPosition() && !next.isFinished()) return false;

    return true;
}

Token* Board::checkCapture(const Token& moved) {
    const Position& pos = moved.getPosition();
    if (!pos.isTrack())        return nullptr;   
    if (isSafe(pos.trackIndex)) return nullptr;  

    Cell& cell = getCell(pos.trackIndex);
    for (Token* t : cell.getTokens()) {
        if (t == &moved)                       continue;
        if (t->getColor() != moved.getColor()) return t;
    }
    return nullptr;
}

Cell& Board::getCell(int trackIndex) {
    if (trackIndex < 0 || trackIndex >= (int)cells.size())
        throw out_of_range("Invalid track index");
    return cells[trackIndex];
}

const Cell& Board::getCell(int trackIndex) const {
    if (trackIndex < 0 || trackIndex >= (int)cells.size())
        throw out_of_range("Invalid track index");
    return cells[trackIndex];
}

void Board::placeToken(Token* token) {
    const Position& pos = token->getPosition();
    if (pos.isTrack())
        getCell(pos.trackIndex).addToken(token);
}

void Board::removeToken(Token* token) {
    const Position& pos = token->getPosition();
    if (pos.isTrack())
        getCell(pos.trackIndex).removeToken(token);
}
