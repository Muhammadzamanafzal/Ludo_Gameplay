#include "Game.h"
#include "Renderer.h"

int main() {
    Game     game;
    Renderer renderer(game, 1100, 750);
    renderer.init();
    renderer.run();
    renderer.shutdown();
    return 0;
}
