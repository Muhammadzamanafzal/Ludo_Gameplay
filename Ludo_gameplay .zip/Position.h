#pragma once

struct Position {
    int trackIndex;   

    Position() : trackIndex(-1) {}
    explicit Position(int idx) : trackIndex(idx) {}

    bool isBase()     const { return trackIndex == -1; }
    bool isFinished() const { return trackIndex == 999; }
    bool isHomeCol()  const { return trackIndex >= 100 && trackIndex <= 105; }
    bool isTrack()    const { return trackIndex >= 0 && trackIndex <= 51; }

    bool operator==(const Position& o) const { return trackIndex == o.trackIndex; }
    bool operator!=(const Position& o) const { return trackIndex != o.trackIndex; }
};
