#pragma once
#include <vector>
#include <stack>
#include "Move.h"
using namespace std;

class MoveManager {
private:
    stack<Move>  undoStack;
    stack<Move>  redoStack;
    vector<Move> history;

public:
    void recordMove(const Move& m);

    bool canUndo() const;
    bool canRedo() const;

    Move popUndo();
    Move popRedo();
    void pushRedo(const Move& m);

    const vector<Move>& getHistory() const;
    void clearRedo();
    void clear();
};
