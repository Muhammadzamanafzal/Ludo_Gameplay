#pragma once
#include <string>
#include <vector>
using namespace std;

class Player;
class MoveManager;

class StateManager {
public:
    static bool saveGame(const string&         filename,
                         const vector<Player>& players,
                         int                   currentPlayerIndex,
                         int                   diceLastRoll,
                         int                   consecutiveSixes,
                         const MoveManager&    mm);

    static bool loadGame(const string&   filename,
                         vector<Player>& players,
                         int&            currentPlayerIndex,
                         int&            diceLastRoll,
                         int&            consecutiveSixes,
                         MoveManager&    mm);
};
