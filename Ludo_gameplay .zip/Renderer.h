#pragma once
#include "raylib.h" 
#include "Game.h"
#include <string>
#include <vector>
using namespace std;

class Renderer {
private:
    Game& game;
    int   screenW;
    int   screenH;
    int   boardSize;
    int   boardOX;
    int   boardOY;
    float cellSize;

   
    int  menuNumPlayers;
    char playerNames[4][32];
    int  activeNameField;

   
    int  selectedThemeIdx;   

    float diceAnimTimer;
    bool  diceAnimating;
    int   diceAnimValue;

    Color themeBackground()    const;
    Color themeTrackCell()     const;
    Color themePanelBg()       const;
    Color themePanelHeader()   const;
    Color themePanelText()     const;
    Color themePanelAccent()   const;
    Color themeKeyBg()         const;
    Color themeKeyBorder()     const;
    Color themeKeyText()       const;

    Color playerRaylibColor(PlayerColor c)      const;
    Color playerRaylibColorLight(PlayerColor c) const;

    void drawBoard();
    void drawHomeAreas();
    void drawTokens();
    void drawDice();
    void drawStatusPanel();
    void drawHighlights();
    void drawCell(int row, int col, Color fill);

    Vector2 trackCellCenter(int trackIdx)                      const;
    Vector2 homeCellCenter(PlayerColor color, int step)        const;
    Vector2 baseCellCenter(PlayerColor color, int tokenIdx)    const;
    Vector2 tokenScreenPos(const Token& t)                     const;

    void drawMenuScreen();
    void drawNameInputScreen();   
    void drawGameScreen();
    void drawGameOverScreen();
    void drawReplayScreen();

    void handleMenuInput();
    void handleNameInput();
    void handleGameInput();
    void handleReplayInput();

    bool isClickOnDice(Vector2 mouse) const;
    int  tokenClickedIdx(Vector2 mouse) const;

public:
    Renderer(Game& game, int screenW = 1100, int screenH = 750);
    void init();
    void run();
    void shutdown();
};
