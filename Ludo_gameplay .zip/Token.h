#pragma once
#include "Position.h"

enum class TokenState { BASE, ACTIVE, FINISHED };
enum class PlayerColor { CRED, CGREEN, CYELLOW, CBLUE };

class Token {
private:
    int         id;
    PlayerColor color;
    Position    position;
    TokenState  state;

public:
    Token(int id, PlayerColor color);

    int         getId()       const;
    PlayerColor getColor()    const;
    Position    getPosition() const;
    TokenState  getState()    const;

    void setPosition(Position pos);
    void setState(TokenState s);

    bool isAtHome()   const;
    bool isFinished() const;
    bool isActive()   const;

    void reset();
};
