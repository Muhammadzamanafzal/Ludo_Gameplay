#include "StateManager.h"
#include "Player.h"
#include "MoveManager.h"
#include <fstream>
#include <sstream>
using namespace std;

bool StateManager::saveGame(const string&         filename,
                            const vector<Player>& players,
                            int                   currentPlayerIndex,
                            int                   diceLastRoll,
                            int                   consecutiveSixes,
                            const MoveManager&    mm)
{
    ofstream file(filename);
    if (!file.is_open()) return false;

    file << "LUDO_SAVE_V2\n";
    file << "numPlayers "         << players.size()        << "\n";
    file << "currentPlayerIndex " << currentPlayerIndex     << "\n";
    file << "diceLastRoll "       << diceLastRoll           << "\n";
    file << "consecutiveSixes "   << consecutiveSixes       << "\n";
    file << "PLAYERS\n";

    for (const Player& p : players) {
        file << "player " << p.getId() << " " << p.getName()
             << " " << (int)p.getColor() << " " << p.getFinishedCount() << "\n";

        for (int i = 0; i < 4; ++i) {
            const Token& t = p.getToken(i);
            file << "  token " << t.getId()
                 << " " << (int)t.getState()
                 << " " << t.getPosition().trackIndex << "\n";
        }
    }

    file << "HISTORY\n";
    for (const Move& m : mm.getHistory()) {
        file << "move "
             << m.playerId   << " " << m.tokenId    << " " << m.diceValue    << " "
             << m.prevPosition.trackIndex            << " " << m.newPosition.trackIndex << " "
             << m.capturedPlayerId                   << " " << m.capturedTokenId        << " "
             << m.capturedPrevPos.trackIndex         << " " << (m.wasTokenActive ? 1 : 0) << "\n";
    }

    file << "END\n";
    return true;
}

bool StateManager::loadGame(const string&   filename,
                            vector<Player>& players,
                            int&            currentPlayerIndex,
                            int&            diceLastRoll,
                            int&            consecutiveSixes,
                            MoveManager&    mm)
{
    ifstream file(filename);
    if (!file.is_open()) return false;

    string line, word;
    getline(file, line);

    bool newFormat = (line == "LUDO_SAVE_V2");
    if (!newFormat && line != "LUDO_SAVE_V1") return false;

    int numPlayers = 0;
    file >> word >> numPlayers;
    file >> word >> currentPlayerIndex;
    file >> word >> diceLastRoll;
    file >> word >> consecutiveSixes;
    file >> word;   

    players.clear();
    mm.clear();

    for (int p = 0; p < numPlayers; ++p) {
        int    id, colorInt, finished;
        string name;
        file >> word >> id >> name >> colorInt >> finished;

        PlayerColor col = (PlayerColor)colorInt;
        players.emplace_back(id, name, col);
        Player& player = players.back();

        player.setFinishedTokens(0);   
        for (int t = 0; t < 4; ++t) {
            int tokenId, stateInt, trackIdx;
            file >> word >> tokenId >> stateInt >> trackIdx;
            Token& tok = player.getToken(tokenId);
            tok.setState((TokenState)stateInt);
            tok.setPosition(Position(trackIdx));
        }
        player.setFinishedTokens(finished);
    }

    file >> word;   
    while (file >> word && word == "move") {
        Move m;
        int prevTrack, newTrack, captPrevTrack;
        int wasActive = 0;
        file >> m.playerId >> m.tokenId >> m.diceValue
             >> prevTrack >> newTrack
             >> m.capturedPlayerId >> m.capturedTokenId >> captPrevTrack;

        if (newFormat) file >> wasActive;

        m.prevPosition      = Position(prevTrack);
        m.newPosition       = Position(newTrack);
        m.capturedPrevPos   = Position(captPrevTrack);
        m.wasTokenActive    = (wasActive != 0);
        mm.recordMove(m);
    }

    return true;
}
