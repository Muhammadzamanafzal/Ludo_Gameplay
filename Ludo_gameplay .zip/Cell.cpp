#include "Cell.h"
#include <algorithm>
using namespace std;

Cell::Cell(int index, bool safe) : index(index), safe(safe) {}

int  Cell::getIndex() const { return index; }
bool Cell::isSafe()   const { return safe; }

void Cell::addToken(Token* token) {
    tokens.push_back(token);
}

void Cell::removeToken(Token* token) {
    tokens.erase(remove(tokens.begin(), tokens.end(), token), tokens.end());
}

const vector<Token*>& Cell::getTokens() const {
    return tokens;
}

bool Cell::hasTokens() const {
    return !tokens.empty();
}
