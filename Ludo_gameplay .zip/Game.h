#pragma once
#include <vector>
#include <string>
#include "Player.h"
#include "Board.h"
#include "MoveManager.h"
#include "StateManager.h"
#include "Move.h"
using namespace std;

enum class GameStatus { MENU, PLAYING, GAME_OVER, REPLAY, NAME_INPUT };
 enum class BoardTheme { CLASSIC, DARK, PASTEL };

class Game {
private:
    vector<Player> players;
    Board          board;
    int            currentPlayerIndex;
    int            lastDiceRoll;
    int            consecutiveSixes;
    bool           diceRolled;
    int            selectedTokenIdx;
    int            replayStep;
    MoveManager    moveManager;
    GameStatus     gameStatus;
    BoardTheme     boardTheme;   

    void applyMove(Move& m);
    void reverseMove(const Move& m);
    void syncBoardCells();

public:
    Game();

    void startGame(int numPlayers, const vector<string>& names);

    int  rollDice();
    bool makeMove(int playerIdx, int tokenIdx);
    void nextTurn();
    Player* checkWinner();

    bool undo();
    bool redo();

    bool saveGame(const string& filename) const;
    bool loadGame(const string& filename);

    bool replayForward();
    bool replayBackward();
    void startReplay();

    const vector<Player>& getPlayers()         const;
    vector<Player>&       getPlayers();
    int                   getCurrentPlayerIndex() const;
    GameStatus            getGameStatus()        const;
    void                  setGameStatus(GameStatus s);
    const Board&          getBoard()             const;
    Board&                getBoard();
    int                   getLastDiceRoll()      const;
    bool                  isDiceRolled()         const;
    int                   getSelectedToken()     const;
    void                  setSelectedToken(int idx);
    int                   getConsecutiveSixes()  const;
    const MoveManager&    getMoveManager()        const;
    int                   getReplayStep()         const;
     BoardTheme  getBoardTheme()            const;
    void        setBoardTheme(BoardTheme t);

    vector<Token*> getMovableTokens();
};
