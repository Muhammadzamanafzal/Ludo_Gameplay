#pragma once
#include "Position.h"

struct Move {
    int      playerId;
    int      tokenId;
    int      steps;
    Position prevPosition;
    Position newPosition;
    int      capturedPlayerId;
    int      capturedTokenId;
    Position capturedPrevPos;
    int      diceValue;
    bool     wasTokenActive;

    Move()
        : playerId(-1), tokenId(-1), steps(0),
          capturedPlayerId(-1), capturedTokenId(-1),
          diceValue(0), wasTokenActive(false)
    {}
};
