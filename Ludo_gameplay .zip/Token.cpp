#include "Token.h"

Token::Token(int id, PlayerColor color)
    : id(id), color(color), position(Position(-1)), state(TokenState::BASE)
{}

int         Token::getId()       const { return id; }
PlayerColor Token::getColor()    const { return color; }
Position    Token::getPosition() const { return position; }
TokenState  Token::getState()    const { return state; }

void Token::setPosition(Position pos) { position = pos; }
void Token::setState(TokenState s)    { state = s; }

bool Token::isAtHome()   const { return state == TokenState::BASE; }
bool Token::isFinished() const { return state == TokenState::FINISHED; }
bool Token::isActive()   const { return state == TokenState::ACTIVE; }

void Token::reset() {
    position = Position(-1);
    state    = TokenState::BASE;
}
