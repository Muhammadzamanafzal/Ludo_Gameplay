#include "MoveManager.h"
using namespace std;

void MoveManager::recordMove(const Move& m) {
    undoStack.push(m);
    history.push_back(m);
    clearRedo();
}

bool MoveManager::canUndo() const { return !undoStack.empty(); }
bool MoveManager::canRedo() const { return !redoStack.empty(); }

Move MoveManager::popUndo() {
    Move m = undoStack.top();
    undoStack.pop();
    return m;
}

Move MoveManager::popRedo() {
    Move m = redoStack.top();
    redoStack.pop();
    return m;
}

void MoveManager::pushRedo(const Move& m) {
    redoStack.push(m);
}

const vector<Move>& MoveManager::getHistory() const {
    return history;
}

void MoveManager::clearRedo() {
    while (!redoStack.empty()) redoStack.pop();
}

void MoveManager::clear() {
    while (!undoStack.empty()) undoStack.pop();
    while (!redoStack.empty()) redoStack.pop();
    history.clear();
}
