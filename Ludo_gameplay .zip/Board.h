#pragma once
#include <vector>
#include <set>
#include "Cell.h"
#include "Token.h"
#include "Position.h"
using namespace std;

class Board {
private:
    vector<Cell> cells;
    set<int>     safeCells;

    int startOffset(PlayerColor c) const;

public:
    Board();

    bool isSafe(int trackIndex) const;

    Position getNextPosition(const Position& pos, int steps, PlayerColor color) const;

    bool   isValidMove(const Token& token, int steps) const;
    Token* checkCapture(const Token& moved);

    Cell&       getCell(int trackIndex);
    const Cell& getCell(int trackIndex) const;

    void placeToken(Token* token);
    void removeToken(Token* token);
};
