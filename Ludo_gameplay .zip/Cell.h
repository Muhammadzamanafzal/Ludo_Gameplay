#pragma once
#include <vector>
#include "Token.h"
using namespace std;

class Cell {
private:
    int           index;
    bool          safe;
    vector<Token*> tokens;

public:
    Cell(int index, bool safe = false);

    int  getIndex() const;
    bool isSafe()   const;

    void addToken(Token* token);
    void removeToken(Token* token);

    const vector<Token*>& getTokens() const;
    bool hasTokens() const;
};
