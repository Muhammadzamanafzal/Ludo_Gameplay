#include "Game.h"
#include <cstdlib>
#include <ctime>
using namespace std;

Game::Game()
    : currentPlayerIndex(0),
      lastDiceRoll(1),
      consecutiveSixes(0),
      diceRolled(false),
      selectedTokenIdx(-1),
      replayStep(0),
      gameStatus(GameStatus::MENU),
      boardTheme(BoardTheme::CLASSIC)
{
    srand((unsigned)time(nullptr));
}

void Game::startGame(int numPlayers, const vector<string>& names) {
    players.clear();
    moveManager.clear();

    PlayerColor colors[] = {
        PlayerColor::CRED, PlayerColor::CGREEN,
        PlayerColor::CYELLOW, PlayerColor::CBLUE
    };
    for (int i = 0; i < numPlayers; ++i)
        players.emplace_back(i, names[i], colors[i]);

    board = Board();

    currentPlayerIndex = 0;
    lastDiceRoll       = 1;
    consecutiveSixes   = 0;
    diceRolled         = false;
    selectedTokenIdx   = -1;
    replayStep         = 0;
    gameStatus         = GameStatus::PLAYING;
}

int Game::rollDice() {
    lastDiceRoll = rand() % 6 + 1;
    diceRolled = true;

    if (lastDiceRoll == 6)
        ++consecutiveSixes;
    else
        consecutiveSixes = 0;

   
    if (consecutiveSixes >= 3) {
        consecutiveSixes = 0;
        diceRolled = false;
        nextTurn();
        return lastDiceRoll;
    }

   
    if (getMovableTokens().empty()) {
        diceRolled = false;  
        nextTurn();
    }

    return lastDiceRoll;
}

bool Game::makeMove(int playerIdx, int tokenIdx) {
    if (playerIdx < 0 || playerIdx >= (int)players.size()) return false;
    if (!diceRolled) return false;

    Player& player = players[playerIdx];
    Token&  token  = player.getToken(tokenIdx);

    if (!board.isValidMove(token, lastDiceRoll)) return false;

    Move m;
    m.playerId       = playerIdx;
    m.tokenId        = tokenIdx;
    m.diceValue      = lastDiceRoll;
    m.steps          = lastDiceRoll;
    m.prevPosition   = token.getPosition();
    m.wasTokenActive = token.isActive();
    m.capturedPlayerId = -1;
    m.capturedTokenId  = -1;

    applyMove(m);
    moveManager.recordMove(m);

 
    if (lastDiceRoll != 6) {
        nextTurn();
    } else {
        diceRolled       = false;
        consecutiveSixes = 0;
    }

    return true;
}

void Game::applyMove(Move& m) {
    Player& player = players[m.playerId];
    Token&  token  = player.getToken(m.tokenId);

    board.removeToken(&token);

    Position next = board.getNextPosition(token.getPosition(), m.steps, token.getColor());
    m.newPosition = next;

    if (next.isBase()) {
        token.setState(TokenState::BASE);
    } else if (next.isFinished()) {
        token.setState(TokenState::FINISHED);
        player.incrementFinished();
    } else {
        token.setState(TokenState::ACTIVE);
    }
    token.setPosition(next);

    board.placeToken(&token);

    if (next.isTrack()) {
        Token* captured = board.checkCapture(token);
        if (captured) {
            m.capturedPlayerId = -1;
            m.capturedTokenId  = captured->getId();
            m.capturedPrevPos  = captured->getPosition();

            for (int pi = 0; pi < (int)players.size(); ++pi) {
                if (players[pi].getColor() == captured->getColor()) {
                    m.capturedPlayerId = pi;
                    break;
                }
            }

            board.removeToken(captured);
            captured->setPosition(Position(-1));
            captured->setState(TokenState::BASE);
        }
    }

    diceRolled = false;
}

void Game::reverseMove(const Move& m) {
    Player& player = players[m.playerId];
    Token&  token  = player.getToken(m.tokenId);

    if (m.newPosition.isFinished() && token.isFinished())
        player.setFinishedTokens(player.getFinishedCount() - 1);

    board.removeToken(&token);

    token.setPosition(m.prevPosition);
    if (m.prevPosition.isBase())
        token.setState(TokenState::BASE);
    else if (m.wasTokenActive)
        token.setState(TokenState::ACTIVE);
    else
        token.setState(TokenState::BASE);

    board.placeToken(&token);

    if (m.capturedPlayerId >= 0 && m.capturedPlayerId < (int)players.size()) {
        Token& cap = players[m.capturedPlayerId].getToken(m.capturedTokenId);
        board.removeToken(&cap);
        cap.setPosition(m.capturedPrevPos);
        cap.setState(TokenState::ACTIVE);
        board.placeToken(&cap);
    }
}

void Game::nextTurn() {
    diceRolled         = false;
    selectedTokenIdx   = -1;
    consecutiveSixes   = 0;
    currentPlayerIndex = (currentPlayerIndex + 1) % (int)players.size();
}

Player* Game::checkWinner() {
    for (Player& p : players)
        if (p.hasWon()) return &p;
    return nullptr;
}

bool Game::undo() {
    if (!moveManager.canUndo()) return false;
    Move m = moveManager.popUndo();
    moveManager.pushRedo(m);
    reverseMove(m);
    currentPlayerIndex = m.playerId;
    diceRolled         = false;
    return true;
}

bool Game::redo() {
    if (!moveManager.canRedo()) return false;
    Move m = moveManager.popRedo();
    applyMove(m);
    moveManager.recordMove(m);
    return true;
}

bool Game::saveGame(const string& filename) const {
    return StateManager::saveGame(filename, players, currentPlayerIndex,
                                  lastDiceRoll, consecutiveSixes, moveManager);
}

bool Game::loadGame(const string& filename) {
    bool ok = StateManager::loadGame(filename, players, currentPlayerIndex,
                                     lastDiceRoll, consecutiveSixes, moveManager);
    if (ok) {
        syncBoardCells();
        gameStatus     = GameStatus::PLAYING;
        diceRolled     = false;
        selectedTokenIdx = -1;
    }
    return ok;
}

void Game::syncBoardCells() {
    board = Board();   
    for (Player& p : players)
        for (Token& t : p.getTokens())
            board.placeToken(&t);
}

void Game::startReplay() {
    for (Player& p : players)
        for (Token& t : p.getTokens()) t.reset();
    board = Board();

    replayStep = 0;
    gameStatus = GameStatus::REPLAY;
}

bool Game::replayForward() {
    const vector<Move>& hist = moveManager.getHistory();
    if (replayStep >= (int)hist.size()) return false;
    Move m = hist[replayStep];
    applyMove(m);
    ++replayStep;
    return true;
}

bool Game::replayBackward() {
    if (replayStep <= 0) return false;
    --replayStep;
    const vector<Move>& hist = moveManager.getHistory();
    reverseMove(hist[replayStep]);
    return true;
}

const vector<Player>& Game::getPlayers()          const { return players; }
vector<Player>&       Game::getPlayers()                { return players; }
int                   Game::getCurrentPlayerIndex() const { return currentPlayerIndex; }
GameStatus            Game::getGameStatus()         const { return gameStatus; }
void                  Game::setGameStatus(GameStatus s)   { gameStatus = s; }
const Board&          Game::getBoard()              const { return board; }
Board&                Game::getBoard()                    { return board; }
int                   Game::getLastDiceRoll()       const { return lastDiceRoll; }
bool                  Game::isDiceRolled()          const { return diceRolled; }
int                   Game::getSelectedToken()      const { return selectedTokenIdx; }
void                  Game::setSelectedToken(int i)       { selectedTokenIdx = i; }
int                   Game::getConsecutiveSixes()   const { return consecutiveSixes; }
const MoveManager&    Game::getMoveManager()        const { return moveManager; }
int                   Game::getReplayStep()         const { return replayStep; }
BoardTheme            Game::getBoardTheme()         const { return boardTheme; }
void                  Game::setBoardTheme(BoardTheme t)   { boardTheme = t; }

vector<Token*> Game::getMovableTokens() {
    if (players.empty()) return {};
    int dice = lastDiceRoll;
    Player& cp = players[currentPlayerIndex];
    vector<Token*> candidates = cp.getMovableTokens(dice);

    vector<Token*> result;
    for (Token* t : candidates)
        if (board.isValidMove(*t, dice))
            result.push_back(t);
    return result;
}
