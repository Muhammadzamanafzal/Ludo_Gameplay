#include "Renderer.h"
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

static const int TRACK_COLS[52] = {
    6,6,6,6,6, 5,4,3,2,1,0, 0,0, 1,2,3,4,5,
    6,6,6,6,6, 6, 7, 8,8,8,8,8,8, 9,10,11,12,13,14,
    14,14, 13,12,11,10,9, 8,8,8,8,8,8, 7,7
};
static const int TRACK_ROWS[52] = {
    13,12,11,10,9, 8,8,8,8,8,8, 7,6, 6,6,6,6,6,
    5,4,3,2,1,0, 0, 0,1,2,3,4,5, 6,6,6,6,6,6,
    7,8, 8,8,8,8,8, 9,10,11,12,13,14, 14,13
};

static void homeColPos(PlayerColor c, int step, int& row, int& col) {
    if (step >= 5) { row = 7; col = 7; return; }
    switch (c) {
    case PlayerColor::CRED:    row = 7;        col = 1 + step; break;
    case PlayerColor::CGREEN:  row = 1 + step; col = 7;        break;
    case PlayerColor::CYELLOW: col = 13 - step; row = 7;       break;
    case PlayerColor::CBLUE:   row = 13 - step; col = 7;       break;
    }
}

static void baseQuadrant(PlayerColor c, int& topRow, int& topCol) {
    switch (c) {
    case PlayerColor::CRED:    topRow = 0; topCol = 0; break;
    case PlayerColor::CGREEN:  topRow = 0; topCol = 9; break;
    case PlayerColor::CYELLOW: topRow = 9; topCol = 9; break;
    case PlayerColor::CBLUE:   topRow = 9; topCol = 0; break;
    }
}

static void baseTokenOffset(int tokenIdx, int& dr, int& dc) {
    dr = (tokenIdx / 2) * 2 + 1;
    dc = (tokenIdx % 2) * 2 + 1;
}

Renderer::Renderer(Game& game, int sw, int sh)
    : game(game), screenW(sw), screenH(sh),
      menuNumPlayers(2), activeNameField(0),
      selectedThemeIdx(0),
      diceAnimTimer(0.0f), diceAnimating(false), diceAnimValue(1)
{
    boardSize = sh - 20;
    boardOX   = 10;
    boardOY   = 10;
    cellSize  = (float)boardSize / 15.0f;

    memset(playerNames, 0, sizeof(playerNames));
    strncpy_s(playerNames[0], "Red",    31);
    strncpy_s(playerNames[1], "Green",  31);
    strncpy_s(playerNames[2], "Yellow", 31);
    strncpy_s(playerNames[3], "Blue",   31);
}

Color Renderer::themeBackground() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{ 245, 235, 210, 255 };
    case BoardTheme::DARK:    return Color{  30,  30,  40, 255 };
    case BoardTheme::PASTEL:  return Color{ 240, 248, 255, 255 };
    }
    return WHITE;
}

Color Renderer::themeTrackCell() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{ 240, 240, 240, 255 };
    case BoardTheme::DARK:    return Color{  50,  50,  65, 255 };
    case BoardTheme::PASTEL:  return Color{ 230, 240, 255, 255 };
    }
    return WHITE;
}

Color Renderer::themePanelBg() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{  26,  10,  10, 255 };
    case BoardTheme::DARK:    return Color{  18,  18,  30, 255 };
    case BoardTheme::PASTEL:  return Color{  60,  40,  80, 255 };
    }
    return BLACK;
}

Color Renderer::themePanelHeader() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{  45,   8,   8, 255 };
    case BoardTheme::DARK:    return Color{  28,  28,  48, 255 };
    case BoardTheme::PASTEL:  return Color{  90,  60, 110, 255 };
    }
    return BLACK;
}

Color Renderer::themePanelText() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{ 232, 208, 208, 255 };
    case BoardTheme::DARK:    return Color{ 200, 200, 220, 255 };
    case BoardTheme::PASTEL:  return Color{ 255, 240, 255, 255 };
    }
    return WHITE;
}

Color Renderer::themePanelAccent() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{ 245, 200,  66, 255 };
    case BoardTheme::DARK:    return Color{  80, 200, 255, 255 };
    case BoardTheme::PASTEL:  return Color{ 255, 180, 220, 255 };
    }
    return YELLOW;
}

Color Renderer::themeKeyBg() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{  42,  16,  16, 255 };
    case BoardTheme::DARK:    return Color{  35,  35,  55, 255 };
    case BoardTheme::PASTEL:  return Color{  80,  50, 100, 255 };
    }
    return DARKGRAY;
}

Color Renderer::themeKeyBorder() const {
    switch (game.getBoardTheme()) {
    case BoardTheme::CLASSIC: return Color{  90,  32,  32, 255 };
    case BoardTheme::DARK:    return Color{  60,  60, 100, 255 };
    case BoardTheme::PASTEL:  return Color{ 160, 100, 200, 255 };
    }
    return GRAY;
}

Color Renderer::themeKeyText() const {
    return themePanelAccent();
}

Color Renderer::playerRaylibColor(PlayerColor c) const {
    switch (c) {
    case PlayerColor::CRED:    return RED;
    case PlayerColor::CGREEN:  return GREEN;
    case PlayerColor::CYELLOW: return YELLOW;
    case PlayerColor::CBLUE:   return BLUE;
    }
    return WHITE;
}

Color Renderer::playerRaylibColorLight(PlayerColor c) const {
    switch (c) {
    case PlayerColor::CRED:    return Color{ 255, 180, 180, 255 };
    case PlayerColor::CGREEN:  return Color{ 180, 255, 180, 255 };
    case PlayerColor::CYELLOW: return Color{ 255, 255, 180, 255 };
    case PlayerColor::CBLUE:   return Color{ 180, 180, 255, 255 };
    }
    return WHITE;
}

Vector2 Renderer::trackCellCenter(int trackIdx) const {
    int r = TRACK_ROWS[trackIdx % 52];
    int c = TRACK_COLS[trackIdx % 52];
    return { boardOX + (c + 0.5f) * cellSize, boardOY + (r + 0.5f) * cellSize };
}

Vector2 Renderer::homeCellCenter(PlayerColor color, int step) const {
    int r, c;
    homeColPos(color, step, r, c);
    return { boardOX + (c + 0.5f) * cellSize, boardOY + (r + 0.5f) * cellSize };
}

Vector2 Renderer::baseCellCenter(PlayerColor color, int tokenIdx) const {
    int tr, tc, dr, dc;
    baseQuadrant(color, tr, tc);
    baseTokenOffset(tokenIdx, dr, dc);
    return { boardOX + (tc + dc + 0.5f) * cellSize, boardOY + (tr + dr + 0.5f) * cellSize };
}

Vector2 Renderer::tokenScreenPos(const Token& t) const {
    const Position& pos = t.getPosition();
    if (pos.isBase())     return baseCellCenter(t.getColor(), t.getId());
    if (pos.isFinished()) return { boardOX + 7.5f * cellSize, boardOY + 7.5f * cellSize };
    if (pos.isHomeCol())  return homeCellCenter(t.getColor(), pos.trackIndex - 100);
    return trackCellCenter(pos.trackIndex);
}

void Renderer::drawCell(int row, int col, Color fill) {
    float x = boardOX + col * cellSize;
    float y = boardOY + row * cellSize;
    DrawRectangleRec({ x, y, cellSize, cellSize }, fill);
    DrawRectangleLinesEx({ x, y, cellSize, cellSize }, 1, Color{ 80, 80, 80, 200 });
}

void Renderer::drawHomeAreas() {
    PlayerColor cols[4] = {
        PlayerColor::CRED, PlayerColor::CGREEN,
        PlayerColor::CYELLOW, PlayerColor::CBLUE
    };
    for (auto c : cols) {
        int tr, tc;
        baseQuadrant(c, tr, tc);
        Color dark = playerRaylibColor(c);
        for (int r = tr; r < tr + 6; ++r)
            for (int cc = tc; cc < tc + 6; ++cc)
                drawCell(r, cc, dark);
        for (int r = tr + 1; r < tr + 5; ++r)
            for (int cc = tc + 1; cc < tc + 5; ++cc)
                drawCell(r, cc, WHITE);
    }

    for (auto c : cols) {
        Color col = playerRaylibColor(c);
        for (int step = 0; step < 5; ++step) {
            int r, cc;
            homeColPos(c, step, r, cc);
            drawCell(r, cc, col);
        }
    }

    float cx  = boardOX + 6 * cellSize;
    float cy  = boardOY + 6 * cellSize;
    float cs3 = cellSize * 3;

    DrawTriangle(
        { cx,           cy         },
        { cx + cs3/2,   cy + cs3/2 },
        { cx + cs3,     cy         },
        playerRaylibColor(PlayerColor::CGREEN));

    DrawTriangle(
        { cx,           cy + cs3   },
        { cx + cs3/2,   cy + cs3/2 },
        { cx,           cy         },
        playerRaylibColor(PlayerColor::CRED));

    DrawTriangle(
        { cx + cs3,     cy + cs3   },
        { cx + cs3/2,   cy + cs3/2 },
        { cx,           cy + cs3   },
        playerRaylibColor(PlayerColor::CBLUE));

    DrawTriangle(
        { cx + cs3,     cy         },
        { cx + cs3/2,   cy + cs3/2 },
        { cx + cs3,     cy + cs3   },
        playerRaylibColor(PlayerColor::CYELLOW));
}

void Renderer::drawBoard() {
    DrawRectangle(boardOX, boardOY, boardSize, boardSize, themeBackground());

    for (int r = 0; r < 15; ++r)
        for (int c = 0; c < 15; ++c)
            drawCell(r, c, themeTrackCell());

    drawHomeAreas();

    int safeSquares[8] = { 0, 8, 13, 21, 26, 34, 39, 47 };
    for (int idx : safeSquares) {
        Vector2 ctr = trackCellCenter(idx);
        DrawCircle((int)ctr.x, (int)ctr.y, cellSize * 0.42f, Color{ 255, 215, 0, 180 });
        int fontSize = (int)(cellSize * 0.55f);
        int tw       = MeasureText("*", fontSize);
        DrawText("*", (int)(ctr.x - tw / 2), (int)(ctr.y - fontSize / 2), fontSize,
                 Color{ 100, 60, 0, 255 });
    }
}

void Renderer::drawHighlights() {
    if (game.getGameStatus() != GameStatus::PLAYING) return;
    if (!game.isDiceRolled()) return;

    vector<Token*> movable = game.getMovableTokens();
    for (Token* t : movable) {
        Vector2 pos = tokenScreenPos(*t);
        DrawCircle((int)pos.x, (int)pos.y, cellSize * 0.42f, Color{ 255, 255, 0, 120 });
    }

    int sel = game.getSelectedToken();
    if (sel >= 0) {
        int pidx = game.getCurrentPlayerIndex();
        const Token& t = game.getPlayers()[pidx].getToken(sel);
        Position next = game.getBoard().getNextPosition(
            t.getPosition(), game.getLastDiceRoll(), t.getColor());
        Vector2 dest;
        if (next.isFinished())
            dest = { boardOX + 7.5f * cellSize, boardOY + 7.5f * cellSize };
        else if (next.isHomeCol())
            dest = homeCellCenter(t.getColor(), next.trackIndex - 100);
        else if (next.isTrack())
            dest = trackCellCenter(next.trackIndex);
        else
            dest = baseCellCenter(t.getColor(), t.getId());

        DrawCircle((int)dest.x, (int)dest.y, cellSize * 0.45f, Color{ 100, 255, 100, 160 });
    }
}

void Renderer::drawTokens() {
    float radius = cellSize * 0.32f;
    for (const Player& p : game.getPlayers()) {
        Color col = playerRaylibColor(p.getColor());
        for (const Token& t : p.getTokens()) {
            if (t.isFinished()) continue;
            Vector2 pos = tokenScreenPos(t);
            DrawCircle((int)pos.x, (int)pos.y, radius, col);
            DrawCircleLines((int)pos.x, (int)pos.y, radius, BLACK);

            char buf[4];
            snprintf(buf, sizeof(buf), "%d", t.getId() + 1);
            int fs = (int)(cellSize * 0.35f);
            DrawText(buf, (int)(pos.x - fs / 4), (int)(pos.y - fs / 2), fs, WHITE);
        }
    }
}

void Renderer::drawDice() {
    int panelX = boardOX + boardSize + 15;
    int diceX  = panelX + 30;
    int diceY  = 260;
    int diceW  = 70;

    DrawRectangleRounded({ (float)diceX, (float)diceY, (float)diceW, (float)diceW },
                         0.2f, 8, Color{ 220, 220, 220, 255 });
    DrawRectangleRoundedLines({ (float)diceX, (float)diceY, (float)diceW, (float)diceW },
                              0.2f, 8, BLACK);

    int val = diceAnimating ? diceAnimValue : game.getLastDiceRoll();

    float cx  = diceX + diceW / 2.0f;
    float cy  = diceY + diceW / 2.0f;
    float r   = 5.0f;
    float off = diceW * 0.27f;

    auto dot = [&](float dx, float dy) {
        DrawCircle((int)(cx + dx), (int)(cy + dy), (int)r, Color{ 30, 30, 30, 255 });
    };

    switch (val) {
    case 1: dot(0, 0); break;
    case 2: dot(-off, -off); dot(off, off); break;
    case 3: dot(-off, -off); dot(0, 0); dot(off, off); break;
    case 4: dot(-off, -off); dot(off, -off); dot(-off, off); dot(off, off); break;
    case 5: dot(-off, -off); dot(off, -off); dot(0, 0); dot(-off, off); dot(off, off); break;
    case 6: dot(-off, -off); dot(off, -off); dot(-off, 0); dot(off, 0); dot(-off, off); dot(off, off); break;
    }
}

void Renderer::drawStatusPanel() {
    int panelX = boardOX + boardSize + 15;
    int panelW = screenW - panelX - 10;
    int panelH = screenH - 20;

    Color bgCol     = themePanelBg();
    Color headerCol = themePanelHeader();
    Color accentCol = themePanelAccent();
    Color textCol   = themePanelText();
    Color divCol    = themeKeyBorder();

    DrawRectangleRounded({ (float)(panelX - 8), 10, (float)(panelW + 8), (float)panelH },
                         0.06f, 8, bgCol);
    DrawRectangleRoundedLines({ (float)(panelX - 8), 10, (float)(panelW + 8), (float)panelH },
                              0.06f, 8, divCol);

    DrawRectangleRounded({ (float)(panelX - 8), 10, (float)(panelW + 8), 80 },
                         0.06f, 8, headerCol);
    DrawLineEx({ (float)(panelX - 8), 90 }, { (float)(panelX + panelW), 90 }, 1.5f, divCol);

    int titleX = panelX + (panelW / 2) - MeasureText("LUDO", 42) / 2;
    DrawText("LUDO", titleX, 20, 42, accentCol);
    const char* sub = "BOARD GAME";
    int subX = panelX + (panelW / 2) - MeasureText(sub, 11) / 2;
    DrawText(sub, subX, 66, 11, textCol);

    int y = 106;

    DrawText("CURRENT TURN", panelX, y, 10, textCol); y += 14;
    if (!game.getPlayers().empty()) {
        int            idx = game.getCurrentPlayerIndex();
        const Player&  cp  = game.getPlayers()[idx];
        Color          col = playerRaylibColor(cp.getColor());

        DrawRectangleRounded({ (float)panelX, (float)y, (float)panelW, 54 }, 0.12f, 8, col);
        DrawRectangleRounded({ (float)panelX, (float)y, (float)(panelW / 2), 54 }, 0.12f, 8,
                             Color{ 255, 255, 255, 30 });
        DrawCircle(panelX + 27, y + 27, 20, Color{ 0, 0, 0, 50 });
        DrawCircleLines(panelX + 27, y + 27, 20, Color{ 255, 255, 255, 90 });
        char init[2] = { cp.getName()[0], '\0' };
        DrawText(init, panelX + 20, y + 18, 20, WHITE);
        DrawText(cp.getName().c_str(), panelX + 54, y + 8,  22, WHITE);
        DrawText("ACTIVE PLAYER",      panelX + 54, y + 34, 11, Color{ 255, 255, 255, 165 });
        y += 68;
    }

    y += 10;
    DrawLine(panelX, y, panelX + panelW, y, divCol); y += 12;

    DrawText("DICE", panelX, y, 10, textCol); y += 60;
    drawDice();
    y += 68;

    DrawLine(panelX, y, panelX + panelW, y, divCol); y += 12;

    DrawText("TOKEN STATUS", panelX, y, 10, textCol); y += 14;
    for (const Player& p : game.getPlayers()) {
        Color col = playerRaylibColor(p.getColor());
        DrawRectangleRounded({ (float)panelX, (float)(y + 2), 14, 14 }, 0.3f, 4, col);
        DrawText(p.getName().c_str(), panelX + 22, y, 16, textCol);

        char inBuf[8];
        snprintf(inBuf, sizeof(inBuf), "In %d", p.getBaseCount());
        int pillX = panelX + panelW - 74;
        DrawRectangleRounded({ (float)pillX, (float)y, 34, 16 }, 0.4f, 4, themeKeyBg());
        DrawText(inBuf, pillX + 4, y + 2, 11, textCol);

        char doneBuf[8];
        snprintf(doneBuf, sizeof(doneBuf), "* %d", p.getFinishedCount());
        int doneX = panelX + panelW - 36;
        DrawRectangleRounded({ (float)doneX, (float)y, 34, 16 }, 0.4f, 4, Color{ 14, 34, 24, 255 });
        DrawText(doneBuf, doneX + 4, y + 2, 11, Color{ 80, 200, 128, 255 });
        y += 26;
    }

    y += 10;
    DrawLine(panelX, y, panelX + panelW, y, divCol); y += 12;

    DrawText("CONTROLS", panelX, y, 10, textCol); y += 14;

    auto drawCtrl = [&](const char* key, const char* desc, int cx, int cy) {
        int kw = MeasureText(key, 14) + 14;
        DrawRectangleRounded({ (float)cx, (float)cy, (float)kw, 20 }, 0.35f, 4, themeKeyBg());
        DrawRectangleRoundedLines({ (float)cx, (float)cy, (float)kw, 20 }, 0.35f, 4, themeKeyBorder());
        DrawText(key,  cx + 7,      cy + 3, 14, themeKeyText());
        DrawText(desc, cx + kw + 6, cy + 3, 14, textCol);
    };

    int mid = panelX + panelW / 2 + 4;
    drawCtrl("U", "Undo",   panelX, y); drawCtrl("R", "Redo",   mid, y); y += 26;
    drawCtrl("S", "Save",   panelX, y); drawCtrl("L", "Load",   mid, y); y += 26;
    drawCtrl("P", "Replay", panelX, y); drawCtrl("ESC", "Menu", mid, y);

    y = panelH - 28;
    const char* themeNames[] = { "Classic", "Dark", "Pastel" };
    char themeBuf[32];
    snprintf(themeBuf, sizeof(themeBuf), "Theme: %s", themeNames[(int)game.getBoardTheme()]);
    DrawText(themeBuf, panelX, y, 11, textCol);
}

void Renderer::drawMenuScreen() {
    ClearBackground(Color{ 40, 20, 10, 255 });
    int titleX = screenW / 2 - MeasureText("LUDO GAME", 50) / 2;
    DrawText("LUDO GAME", titleX, 80, 50, YELLOW);

    int bx = screenW / 2 - 120, by = 200, bw = 240, bh = 55, gap = 70;

    DrawRectangleRounded({ (float)bx, (float)by,         (float)bw, (float)bh }, 0.3f, 8, Color{ 180, 50, 50, 255 });
    DrawText("New Game",  bx + 50, by + 14, 24, WHITE);

    DrawRectangleRounded({ (float)bx, (float)(by + gap),     (float)bw, (float)bh }, 0.3f, 8, Color{ 50, 50, 180, 255 });
    DrawText("Load Game", bx + 46, by + gap + 14, 24, WHITE);

    DrawRectangleRounded({ (float)bx, (float)(by + gap * 2), (float)bw, (float)bh }, 0.3f, 8, Color{ 80, 80, 80, 255 });
    DrawText("Exit",      bx + 90, by + gap * 2 + 14, 24, WHITE);
}

void Renderer::drawNameInputScreen() {
    ClearBackground(Color{ 30, 30, 50, 255 });
    DrawText("Game Setup", screenW / 2 - MeasureText("Game Setup", 36) / 2, 40, 36, WHITE);

    DrawText("Players:", 100, 120, 22, LIGHTGRAY);
    for (int i = 2; i <= 4; ++i) {
        int bx = 220 + (i - 2) * 80;
        Color bc = (menuNumPlayers == i) ? YELLOW : GRAY;
        DrawRectangle(bx, 116, 60, 30, bc);
        char buf[4]; snprintf(buf, sizeof(buf), "%d", i);
        DrawText(buf, bx + 22, 120, 22, BLACK);
    }

    DrawText("Player Names:", 100, 180, 22, LIGHTGRAY);
    const char* colorNames[] = { "Red", "Green", "Yellow", "Blue" };
    Color       colorVals[]  = { RED,   GREEN,   YELLOW,   BLUE   };

    for (int i = 0; i < menuNumPlayers; ++i) {
        int iy = 220 + i * 60;
        DrawRectangle(80, iy - 4, 14, 14, colorVals[i]);
        DrawText(colorNames[i], 100, iy, 18, colorVals[i]);
        Color bk = (activeNameField == i) ? Color{ 60, 60, 80, 255 } : Color{ 40, 40, 60, 255 };
        DrawRectangle(200, iy - 2, 260, 28, bk);
        DrawRectangleLines(200, iy - 2, 260, 28, LIGHTGRAY);
        DrawText(playerNames[i], 206, iy + 2, 18, WHITE);
        if (activeNameField == i && ((int)(GetTime() * 2) % 2 == 0))
            DrawText("|", 206 + MeasureText(playerNames[i], 18), iy + 2, 18, WHITE);
    }

    int themeY = 220 + menuNumPlayers * 60 + 10;
    DrawText("Board Theme:", 100, themeY, 20, LIGHTGRAY);

    const char* themeLabels[] = { "Classic", "Dark", "Pastel" };
    Color       themeColors[] = {
        Color{ 245, 200,  66, 255 },   
        Color{  80, 200, 255, 255 },   
        Color{ 255, 180, 220, 255 }    
    };
    for (int i = 0; i < 3; ++i) {
        int tx = 250 + i * 110;
        bool sel = (selectedThemeIdx == i);
        Color border = sel ? themeColors[i] : Color{ 80, 80, 100, 255 };
        Color bg     = sel ? Color{ 60, 60, 80, 255 } : Color{ 40, 40, 60, 255 };
        DrawRectangleRounded({ (float)tx, (float)themeY - 2, 100, 28 }, 0.3f, 6, bg);
        DrawRectangleRoundedLines({ (float)tx, (float)themeY - 2, 100, 28 }, 0.3f, 6, border);
        DrawText(themeLabels[i], tx + 8, themeY + 4, 16, sel ? themeColors[i] : GRAY);
    }

    int startY = themeY + 50;
    DrawRectangleRounded({ (float)(screenW / 2 - 80), (float)startY, 160, 44 },
                         0.3f, 8, Color{ 50, 180, 50, 255 });
    DrawText("START", screenW / 2 - MeasureText("START", 24) / 2, startY + 10, 24, WHITE);
    DrawText("Click a name field to type. Press Enter/Tab to switch.",
             60, startY + 60, 14, GRAY);
}

void Renderer::drawGameScreen() {
    ClearBackground(themeBackground());
    drawBoard();
    drawHighlights();
    drawTokens();
    drawStatusPanel();
}

void Renderer::drawGameOverScreen() {
    DrawRectangle(0, 0, screenW, screenH, Color{ 0, 0, 0, 180 });
    Player* winner = game.checkWinner();
    if (winner) {
        Color col = playerRaylibColor(winner->getColor());
        DrawText("WINNER!", screenW / 2 - MeasureText("WINNER!", 60) / 2, 150, 60, col);
        DrawText(winner->getName().c_str(),
                 screenW / 2 - MeasureText(winner->getName().c_str(), 40) / 2, 230, 40, WHITE);
    }
    DrawText("[P] Replay  [ESC] Back to Menu",
             screenW / 2 - MeasureText("[P] Replay  [ESC] Back to Menu", 22) / 2,
             340, 22, LIGHTGRAY);
}

void Renderer::drawReplayScreen() {
    ClearBackground(themeBackground());
    drawBoard();
    drawTokens();

    DrawRectangle(0, 0, screenW, 36, Color{ 0, 0, 0, 160 });
    char buf[80];
    snprintf(buf, sizeof(buf), "REPLAY  Step %d / %d",
             game.getReplayStep(),
             (int)game.getMoveManager().getHistory().size());
    DrawText(buf, 20, 8, 20, WHITE);
    DrawText("[LEFT] Back  [RIGHT] Forward  [ESC] Exit Replay", 300, 8, 16, YELLOW);
}

void Renderer::handleMenuInput() {
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        Vector2 m  = GetMousePosition();
        int bx = screenW / 2 - 120, by = 200, bw = 240, bh = 55, gap = 70;

        if (m.x >= bx && m.x <= bx + bw && m.y >= by && m.y <= by + bh) {
            activeNameField  = 0;
            selectedThemeIdx = 0;
            game.setGameStatus(GameStatus::NAME_INPUT);
        }
        if (m.x >= bx && m.x <= bx + bw && m.y >= by + gap && m.y <= by + gap + bh) {
            if (game.loadGame("ludo_save.txt"))
                game.setGameStatus(GameStatus::PLAYING);
        }
        if (m.x >= bx && m.x <= bx + bw && m.y >= by + gap * 2 && m.y <= by + gap * 2 + bh)
            CloseWindow();
    }
    if (IsKeyPressed(KEY_ESCAPE)) CloseWindow();
}

void Renderer::handleNameInput() {
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        Vector2 m = GetMousePosition();

        for (int i = 2; i <= 4; ++i) {
            int bx = 220 + (i - 2) * 80;
            if (m.x >= bx && m.x <= bx + 60 && m.y >= 116 && m.y <= 146)
                menuNumPlayers = i;
        }

        for (int i = 0; i < menuNumPlayers; ++i) {
            int iy = 220 + i * 60;
            if (m.x >= 200 && m.x <= 460 && m.y >= iy - 2 && m.y <= iy + 26)
                activeNameField = i;
        }

        int themeY = 220 + menuNumPlayers * 60 + 10;
        for (int i = 0; i < 3; ++i) {
            int tx = 250 + i * 110;
            if (m.x >= tx && m.x <= tx + 100 && m.y >= themeY - 2 && m.y <= themeY + 26) {
                selectedThemeIdx = i;
                game.setBoardTheme((BoardTheme)i);
            }
        }

        int startY = themeY + 50;
        if (m.x >= screenW / 2 - 80 && m.x <= screenW / 2 + 80 &&
            m.y >= startY && m.y <= startY + 44)
        {
            vector<string> names;
            for (int i = 0; i < menuNumPlayers; ++i)
                names.push_back(strlen(playerNames[i]) ? playerNames[i] : ("P" + to_string(i + 1)));
            game.startGame(menuNumPlayers, names);
          
        }
    }

    int key = GetCharPressed();
    while (key > 0) {
        int len = (int)strlen(playerNames[activeNameField]);
        if (key >= 32 && key < 127 && len < 15) {
            playerNames[activeNameField][len]     = (char)key;
            playerNames[activeNameField][len + 1] = '\0';
        }
        key = GetCharPressed();
    }
    if (IsKeyPressed(KEY_BACKSPACE)) {
        int len = (int)strlen(playerNames[activeNameField]);
        if (len > 0) playerNames[activeNameField][len - 1] = '\0';
    }
    if (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_TAB))
        activeNameField = (activeNameField + 1) % menuNumPlayers;
    if (IsKeyPressed(KEY_ESCAPE))
        game.setGameStatus(GameStatus::MENU);
}

bool Renderer::isClickOnDice(Vector2 mouse) const {
    int panelX = boardOX + boardSize + 15;
    int diceX  = panelX + 30, diceY = 260, diceW = 70;
    return mouse.x >= diceX && mouse.x <= diceX + diceW &&
           mouse.y >= diceY && mouse.y <= diceY + diceW;
}

int Renderer::tokenClickedIdx(Vector2 mouse) const {
    float          radius  = cellSize * 0.42f;
    vector<Token*> movable = game.getMovableTokens();
    for (Token* t : movable) {
        Vector2 pos = tokenScreenPos(*t);
        float dx = mouse.x - pos.x, dy = mouse.y - pos.y;
        if (dx * dx + dy * dy <= radius * radius) return t->getId();
    }
    return -1;
}

void Renderer::handleGameInput() {
    if (IsKeyPressed(KEY_U)) game.undo();
    if (IsKeyPressed(KEY_R)) game.redo();   
    if (IsKeyPressed(KEY_S)) game.saveGame("ludo_save.txt");
    if (IsKeyPressed(KEY_L)) game.loadGame("ludo_save.txt");
    if (IsKeyPressed(KEY_P)) game.startReplay();
    if (IsKeyPressed(KEY_ESCAPE)) game.setGameStatus(GameStatus::MENU);

    if (!game.isDiceRolled()) {
        bool roll = IsKeyPressed(KEY_SPACE) ||
                    (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && isClickOnDice(GetMousePosition()));
        if (roll) {
            diceAnimating = true;
            diceAnimTimer = 0.0f;
            game.rollDice();
        }
    }

    if (game.isDiceRolled() && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        Vector2 m       = GetMousePosition();
        int     clicked = tokenClickedIdx(m);
        if (clicked >= 0) {
            if (game.getSelectedToken() == clicked) {
                game.makeMove(game.getCurrentPlayerIndex(), clicked);
                game.setSelectedToken(-1);
            } else {
                game.setSelectedToken(clicked);
            }
        }
    }
}

void Renderer::handleReplayInput() {
    if (IsKeyPressed(KEY_RIGHT)) game.replayForward();
    if (IsKeyPressed(KEY_LEFT))  game.replayBackward();
    if (IsKeyPressed(KEY_ESCAPE)) game.setGameStatus(GameStatus::GAME_OVER);
}

void Renderer::init() {
    InitWindow(screenW, screenH, "Ludo - BSAI25022");
    SetTargetFPS(60);
}

void Renderer::run() {
    while (!WindowShouldClose()) {
        float dt = GetFrameTime();

        if (diceAnimating) {
            diceAnimTimer += dt;
            diceAnimValue = (int)(GetTime() * 10) % 6 + 1;
            if (diceAnimTimer > 0.5f) diceAnimating = false;
        }

        BeginDrawing();
        GameStatus status = game.getGameStatus();

        if (status == GameStatus::MENU) {
            drawMenuScreen();
            handleMenuInput();
        }
        else if (status == GameStatus::NAME_INPUT) {
            drawNameInputScreen();
            handleNameInput();
        }
        else if (status == GameStatus::PLAYING) {
            drawGameScreen();
            handleGameInput();
            if (game.checkWinner())
                game.setGameStatus(GameStatus::GAME_OVER);
        }
        else if (status == GameStatus::GAME_OVER) {
            drawGameScreen();     
            drawGameOverScreen(); 
            if (IsKeyPressed(KEY_ESCAPE)) game.setGameStatus(GameStatus::MENU);
            if (IsKeyPressed(KEY_P))      game.startReplay();
        }
        else if (status == GameStatus::REPLAY) {
            drawReplayScreen();
            handleReplayInput();
        }

        EndDrawing();
    }
}
void Renderer::shutdown() {
    CloseWindow();
}
